console.log('Injected!');let ThreeAPI;let oVersionKey='1660844401';let versionKey=oVersionKey;function SpoofVersion(bool){if(bool)
versionKey=document.getElementById('versionKey').innerHTML;else versionKey=oVersionKey;}
SpoofVersion(true);let debug=false;let globalInstance=null;let globalNotificationPtr=null;let styles=[];let camHeight=1.6;let betterNarrowCharacter='‎';let labArray=[];let pingTimer=0;let gameFramerate=0;let qty=0;let avrgDmg=0;let gamesTargetFramerate=60;let vsyncActive=true;let tmpFunc=null;let tmpFunc2=null;const delay=ms=>new Promise(res=>setTimeout(res,ms));function createLab(id,x,y,text,color,explorer){var labelTest=document.createElement('div');labelTest.style.position='absolute';labelTest.style.width=100;labelTest.id=id;labelTest.className="main-menu-button-text whiteBigText blueNight";labelTest.style.height=100;labelTest.style.color=100;labelTest.style.backgroundColor='transparent';labelTest.innerHTML=text;if(explorer==undefined){labelTest.style.bottom=y+'px';labelTest.style.left=x+'px';labArray.push(labelTest);}else{labelTest.style.bottom=y+'px';labelTest.style.right=x+'px';globalInstance.explorer.PushItem(labelTest);}
document.body.appendChild(labelTest);};function ClearLabels(){for(let i=0;i<labArray.length;i++)
labArray[i].remove();labArray=[];}
function ReloadLabels(){ClearLabels()
let keepInTouch=["FPS","Ping","DMG","","VERSION","NARROWVERSION"]
keepInTouch.reverse();for(let i=0;i<keepInTouch.length;i++)
if(keepInTouch[i]!="")
createLab(keepInTouch[i],10,10+(25*i),keepInTouch[i].toUpperCase()+": 0","white")
GetLabelById("VERSION").innerHTML="v1.2.0";GetLabelById("NARROWVERSION").innerHTML=versionKey;}
const GetLabelById=id=>document.getElementById(id);class EnvironmentExplorer{constructor(t){this.scene=t;this.explorerLab=[];}
PushItem(item){this.explorerLab.push(item);}
init(){this.RefreshWindow();}
ClearWindow(){for(let i=0;i<this.explorerLab.length;i++)
this.explorerLab[i].remove();this.explorerLab=[];}
RefreshWindow(){this.ClearWindow()
let explorerItems=[]
scene.traverse(function(obj){if(explorerItems.length>=24)
explorerItems.shift();if(obj!=undefined&&obj!=null)
explorerItems.push(obj.name===""?"UNDEFINED":obj.name);});for(let i=0;i<explorerItems.length;i++)
createLab(explorerItems[i],10,10+(25*i),explorerItems[i],"white",true)}}
class TreroClientHandle{constructor(websocket){this.ws=new WebSocket(websocket);this.ws.addEventListener("message",(i=>{const packet=JSON.parse(i.data);switch(packet.status){case"ping":this.SendStatus("pong");break;case"log":console.log(packet.data);break;}}));this.ws.addEventListener("open",(i=>{this.Send(JSON.stringify({status:"broadcast",data:"hey guys im from another client"}));}));}
Send(data){this.ws.send(data);}
SendStatus(data){this.ws.send(JSON.stringify({status:data}));}}
class BetterNarrow{onFrameRender_Event=new Event('onFrameRender')
onInitialization_Event=new Event('onInitialization')
GetClient(){return globalInstance}
Log(plugin,output){console.log('['+plugin+'] '+output);}
onFrameRender(func){window.addEventListener("onFrameRender",function(){func(ThreeAPI);});}
onInitialization(func){window.addEventListener("onInitialization",function(){func(ThreeAPI,BetterNarrowAPI.GetClient());});}}
let BetterNarrowAPI=new BetterNarrow();function waitForElm(selector){return new Promise(resolve=>{if(document.querySelector(selector)){return resolve(document.querySelector(selector));}
const observer=new MutationObserver(mutations=>{if(document.querySelector(selector)){resolve(document.querySelector(selector));observer.disconnect();}});observer.observe(document.body,{childList:true,subtree:true});});}
function checkBNupdate(url){var request=new XMLHttpRequest();request.open("GET",url,true);request.send();request.onload=function(){status=request.status;if(request.status==200)
{console.log("update exists");alert('A new version of BetterNarrow has been spotted! Go download it!');}else{console.log("update doesn't exist");}}}
checkBNupdate("https://raw.githubusercontent.com/Selkensy/betternarrowimages/master/betternarrowbackup/BetterNarrow-1.2.1.zip");init();